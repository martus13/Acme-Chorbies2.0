
package domain;

public enum RelationshipType {
	activities, friendship, love;
}
